const { Client } = require("pg");

module.exports = function () {
  const client = new Client({
    host: "learningdatabase.c7fabwkiehy2.us-east-1.rds.amazonaws.com",
    user: "postgres",
    password: "cZLQj&wR2*L&wyp3xXc$J2GU67oVtMh^ONGWQtABSbsPBD%w#&4KN",
  });
  return client;
};
